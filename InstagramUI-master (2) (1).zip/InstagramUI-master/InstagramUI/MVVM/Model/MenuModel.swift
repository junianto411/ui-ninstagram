//
//  MenuModel.swift
//  InstagramUI
//
//  Created by Admin on 26/08/22.
//

import Foundation

struct MenuModel:Identifiable {
    var id: Int
    
    var menuIMG:String
    var menuName:String
}
