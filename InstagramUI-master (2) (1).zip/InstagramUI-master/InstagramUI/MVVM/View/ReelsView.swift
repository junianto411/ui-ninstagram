//
//  ReelsView.swift
//  InstagramUI
//
//  Created by Admin on 31/08/22.
//

import SwiftUI

struct ReelsView: View {
    var body: some View {
        Text("Pending Work")
    }
}

struct ReelsView_Previews: PreviewProvider {
    static var previews: some View {
        ReelsView()
    }
}
